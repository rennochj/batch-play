import pandas as pd

data = pd.read_excel("/data/my-data.xlsx")

print(data)

